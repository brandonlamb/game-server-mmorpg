#!/usr/bin/python
#-*- encoding: utf8 -*-

import os
import commands
import re
import string

SHELL_ROOT='./shell/'
RES_SYNC_SHELL=SHELL_ROOT + 'easter_sync_res_v2.sh'
RES_PACK_SHELL=SHELL_ROOT + 'easter_package_res_v2.sh'
SUCCESS_FLAG='execute success'
VER_MAPPING_INFO = '0.1.2.x --> gameData1.0.2<br>'

USERS={
'package':'!@#$%^&*',
'admin':'admin_netmeeting'
}

def exec_shell(cmd):
    return commands.getoutput(cmd)


def is_correct_ver_format(version):
   if not version:
      return False
   '''判断是否正确的版本号格式'''
   p = re.compile('^(\d+\.){3}\d+$')
   if not p.match(version) :
       return False
   return True

def get_ver_int(ver):
    value = ver.split(".")
    return int(value[3]) + int(value[2])*1000 + int(value[1])*1000*1000 + int(value[0])*1000*1000*1000

def is_exec_success(resp):
    if not resp:
        return False
    return string.find(resp,SUCCESS_FLAG) > -1


def res_sync(version):
    cmd = '%s %s'%(RES_SYNC_SHELL,version)
    resp = exec_shell(cmd)
    return is_exec_success(resp),resp
    
    
def res_pack(version):
    cmd = '%s %s'%(RES_PACK_SHELL,version)
    resp = exec_shell(cmd)
    return is_exec_success(resp),resp
