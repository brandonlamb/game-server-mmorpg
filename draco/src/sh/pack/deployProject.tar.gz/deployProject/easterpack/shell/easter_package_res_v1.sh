#!/bin/bash
TAR='/bin/tar'
DEPLOY_PATH='/data/deploy/easter'
SOURCE_NAME='resources'
TARGET_FULL_NAME_PREFIX=/var/ftp/pub/shenzhou/resources

if [ $# -ne 1 ] ; then
  echo '-------------------------'
  echo "USAGE: $0 version"
  echo " e.g.: $0 0.0.0.1"
  echo '-------------------------'
  exit ;
fi

#check the version value

VERSION=$1
#VERSION_PRE=`echo $VERSION|awk -F. '{print $1"."$2"."$3}'`
TARGET_FULL_NAME=${TARGET_FULL_NAME_PREFIX}_${VERSION}_tar.gz

#DEPLOY_PATH=${DEPLOY_PATH}_${VERSION_PRE}
#echo $VERSION_PRE
#echo $DEPLOY_PATH

if [ -f "$TARGET_FULL_NAME" ]; then
 echo '------------------------------------------------'
 echo "the version: $VERSION exists. file: $TARGET_FULL_NAME"
 echo '------------------------------------------------'
 exit ;
fi

if [ ! -d "$DEPLOY_PATH/$SOURCE_NAME" ]; then
 echo '------------------------------------------------'
 echo "the source not exists: path: $DEPLOY_PATH/$SOURCE_NAME"
 echo '------------------------------------------------'
 exit ;
fi

#cd `dirname $0`
cd $DEPLOY_PATH
	
   #echo `pwd`
	
   NO_MAPS=`ls ./resources/resource/ | grep -v ^map__*`

   BUFF=

   for map in $NO_MAPS
    do
       BUFF=$BUFF' --exclude=*/resource/'${map}
    done

	#echo $BUFF
	#exit ;

   SOURCE_VERSION_NAME=${SOURCE_NAME}_${VERSION}
   ln -s ${SOURCE_NAME} ${SOURCE_VERSION_NAME}
   ${TAR} --exclude="*/.svn" --exclude="*/*.gif" --exclude="*/*.png" --exclude="*/*.psd" --exclude="*/*.bmp" --exclude="*/*.jpg" --exclude="*/*.doc" --exclude="*/*.docx" ${BUFF} -hczf ${TARGET_FULL_NAME} ${SOURCE_VERSION_NAME} && echo -e "execute success" || {echo -e "execute failure" ; rm -f ${TARGET_FULL_NAME}}
 rm -rf ${SOURCE_VERSION_NAME}



