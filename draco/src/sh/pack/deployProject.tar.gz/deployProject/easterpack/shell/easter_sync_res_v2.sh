#!/bin/bash

export LANG=zh_CN.UTF-8
SVN_CMD=/usr/bin/svn
RES_PATH=/data/project/easter_res
SVN_URL=http://192.168.20.233/shenzhou/public
SVN_USER=pack
SVN_PWD='83(#lf7L@dG393'

if [ $# -ne 1 ] ; then
  echo '-------------------------'
  echo "USAGE: $0 version"
  echo " e.g.: $0 0.0.6.0"
  echo " svn path: gameData_0.0.6"
  echo " if the path which input not exist in svn,this sync will failure"
  echo '-------------------------'
  exit ;
fi

VERSION=$1
VERSION_PRE=`echo $VERSION|awk -F. '{print $1"."$2"."$3}'`

TARGET_NAME=gameData_$VERSION_PRE

TARGET_RES_PATH=$RES_PATH/$TARGET_NAME

if [ ! -d "$TARGET_RES_PATH" ]; then
 # svn co
 $SVN_CMD co --username $SVN_USER --password $SVN_PWD $SVN_URL/$TARGET_NAME $RES_PATH 
else
 $SVN_CMD up --username $SVN_USER --password $SVN_PWD $TARGET_RES_PATH
fi

if [ "$?" -ne 0 ];then
    echo "execute failure"
else
    echo "execute success"
fi

