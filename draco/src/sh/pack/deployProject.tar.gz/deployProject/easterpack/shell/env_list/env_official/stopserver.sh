#!/bin/sh
#
cd `dirname $0`

#JAVA_HOME=/usr/local/java
SERVER_NAME=`pwd`/shellclient.sh

STDOUT=`pwd`/shellclient.log
STDERR=`pwd`/shellclient_err.log
#STDOUT=/dev/null
#STDERR=/dev/null
APPID=SHELLCLIENT

ARGS=

CLASS_NAME=sacred.alliance.magic.app.shutdown.ShellClient

LIB=`pwd`/lib

JARS=(`ls lib`)
DIRNUM=${#JARS[@]}

CLASS_PATH=./

index=0
while [ $index -lt $DIRNUM ]
do
  CLASS_PATH=$CLASS_PATH:$LIB/${JARS[$index]}
  let "index= $index + 1"
done


function doAction(){
	SUCCESS="run $1 success"
	VAR=`java -D$APPID -classpath $CLASS_PATH $CLASS_NAME $1 $2`
	#echo "\$VAR : $VAR"
	RET=`echo "$VAR" |grep "$SUCCESS" | grep -v grep | wc -l`
	#echo "\$RET : $RET  \$SUCCESS : $SUCCESS"
	if [[ $RET > 0 ]]
	then
    	return 0 
	else
    	return 1
	fi
}


echo '--------------start to push tips to client-----------------'
doAction 4000 3

if [[ $? = 0 ]];then
 	sleep 60
	doAction 4000 2
	if [[ $? = 0 ]];then
		#echo "#2 $? #"
		sleep 60
		doAction 4000 1
		if [[ $? = 0 ]];then
			#echo "#3 $? #"
			echo '---------------start to set rejectReq -----------------'
			doAction 4002 1
			if [[ $? = 0 ]];then
				sleep 60
				echo '---------------start to offline user -------------'
				doAction 4001 1
				if [[ $? = 0 ]];then
					./easterrun.sh stop
				fi
			fi
		fi
	#else
		#echo "#2 $? #"
	fi
fi
