#!/bin/sh
#
CURR_PATH=`dirname $0`
cd $CURR_PATH
AREA_URL=http://192.168.20.13:19310/list

#sed -i '/^currentPath/d' config.properties
#echo 'currentPath='`pwd` >> config.properties

JAVA_HOME=/usr/local/java
SERVER_NAME=`pwd`/easterrun.sh

STDOUT=`pwd`/stdout.log
STDERR=`pwd`/stderr.log
#STDOUT=/dev/null
#STDERR=/dev/null


ARGS=
APPID=easter
PROPERTY=java.nio.channels.spi.SelectorProvider=sun.nio.ch.EPollSelectorProvider

CLASS_NAME=sacred.alliance.magic.core.server.Server

LIB=`pwd`/lib

JARS=(`ls lib`)
DIRNUM=${#JARS[@]}

CLASS_PATH=./

index=0
while [ $index -lt $DIRNUM ]
do
  CLASS_PATH=$CLASS_PATH:$LIB/${JARS[$index]}
  let "index= $index + 1"
done

export LANG=zh_CN.UTF-8
export LC_ALL=zh_CN.UTF-8

counter=`ps -ef|grep $APPID |grep java|grep -v grep|wc -l`
procid=`ps -ef|grep $APPID |grep java|grep -v grep |awk '{print $2}'`


#============================================================================


start()
{
if [ $counter -ge 1 ]
        then
                echo
                echo The $SERVER_NAME Server already Started!
                echo
        else
				echo "start to get the serverId"
				curr_ip=`ip add show eth0 | awk  -F'[/ ]+' '/inet /{print $3}'`
				echo "current ip= $curr_ip"
                server_id=`curl $AREA_URL|grep "host=$curr_ip:10400"|awk -F"(" '{print $2}'|awk -F")" '{print $1}'`
				echo "the serverId= $server_id"
					
				cd $CURR_PATH
				echo "start to gen the log4j.properties"
				rm -rf log4j.properties log4j-stat.properties
				cp ./log_conf/log4j-stat.properties ./log4j-stat.properties
				serverid_replace='${serverid}'
				len_serverid=`echo $server_id|wc -L`
				if [ $len_serverid -ne 3 ] ; then
					echo "get the server id error "
					return 
				fi
				server_id=${server_id#0}
				server_id=${server_id#0}
				sed -i "s/${serverid_replace}/$server_id/g" ./log4j-stat.properties
				cat ./log_conf/log4j-game.properties >> ./log4j.properties
				cat ./log4j-stat.properties >> ./log4j.properties
				rm -rf log4j-stat.properties
				echo "gen the log5j.properties success "
				
                echo Start The $SERVER_NAME Server....
              
               #java -D$APPID -classpath $CLASS_PATH -D$restartshell $CLASS_NAME $ARGS>>$STDOUT 2>>$STDERR & 
               $JAVA_HOME/bin/java -D$APPID -Dtest=false -Dcom.sun.management.jmxremote.ssl=false -Dcom.sun.management.jmxremote.authenticate=false -Dcom.sun.management.jmxremote.port=10100 -Djava.rmi.server.hostname=$curr_ip -Xmx1024m -XX:MaxNewSize=256m -XX:MaxPermSize=256m -classpath $CLASS_PATH -D$PROPERTY $CLASS_NAME $ARGS>>$STDOUT 2>>$STDERR & 

                sleep 2
                counter=`ps -ef|grep $APPID |grep java|grep -v grep|wc -l`
                if [ $counter -eq 1 ]
                        then
                                echo The $SERVER_NAME Server Started!
                                echo
                        else
                               
				echo The $SERVER_NAME Server Start Failed
                                echo please Check the system
                                echo
                fi
fi

#log start


}

stop()
{
if  [ $counter -eq 1 ]
        then    
                echo
                echo Stop The $SERVER_NAME Server....
                echo
				
						kill $procid
                		sleep 10
                        counter=`ps -ef|grep $APPID |grep java|grep -v grep|wc -l`
                		if [ $counter -eq 1 ]
                        	then
								echo `date +%F-%H:%M:%S`" stop epoch server failed! kill -9." >> /data/deploy/kill_easter.log
                                echo The $SERVER_NAME Server NOT Stoped!
                                echo please Check the system
                                echo
                                kill -9 $procid
                                echo "The $SERVER_NAME Server Stoped"
                        	else
                                echo The $SERVER_NAME Server Stoped
                                echo
                		fi
         
        else
                echo
                echo The $SERVER_NAME Server already Stoped!
                echo
fi

#log stop

}


status()
{
echo
if [ $counter -ge 1 ]
        then
                                echo "The $SERVER_NAME Server Running($procid)!"
                                echo
        else
                echo
                echo The $SERVER_NAME Server NOT Running!
                echo
fi
}

case "$1" in
'start')
                start
        ;;
'stop')
                stop
        ;;
'restart')
		stop
		start
	;;
'status')
                status
        ;;
*)
        echo
        echo
        echo "Usage: $0 {status | start | stop }"
        echo
        echo Status of $SERVER_NAME Servers ......
                status
        ;;
esac
exit 0


