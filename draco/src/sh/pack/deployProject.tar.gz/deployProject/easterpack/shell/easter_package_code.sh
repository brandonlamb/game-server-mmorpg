#!/bin/bash
TAR='/bin/tar'
DEPLOY_PATH='/data/deploy'
SOURCE_NAME='easter'

TARGET_FULL_NAME_PREFIX=/var/ftp/pub/shenzhou/easter

if [ $# -ne 1 ] ; then
  echo '-------------------------'
  echo "USAGE: $0 version"
  echo " e.g.: $0 0.0.0.1"
  echo '-------------------------'
  exit ;
fi
#check the version value

VERSION=$1

######### new
VERSION_PRE=`echo $VERSION|awk -F. '{print $1"."$2"."$3}'`
SOURCE_NAME=${SOURCE_NAME}_${VERSION_PRE}
######### end new

TARGET_FULL_NAME=${TARGET_FULL_NAME_PREFIX}_${VERSION}_tar.gz

if [ -f "$TARGET_FULL_NAME" ]; then
 echo '------------------------------------------------'
 echo "the version: $VERSION exists. file: $TARGET_FULL_NAME"
 echo '------------------------------------------------'
 exit ;
fi

if [ ! -d "$DEPLOY_PATH/$SOURCE_NAME" ]; then
 echo '------------------------------------------------'
 echo "the source not exists: path: $DEPLOY_PATH/$SOURCE_NAME"
 echo '------------------------------------------------'
 exit ;
fi

#cd `dirname $0`
cd $DEPLOY_PATH
   SOURCE_VERSION_NAME=easter_${VERSION}
   ln -s ${SOURCE_NAME} ${SOURCE_VERSION_NAME}
   ${TAR} --exclude="${SOURCE_VERSION_NAME}/sync_resources.sh" --exclude="${SOURCE_VERSION_NAME}/sync_code.sh" --exclude="${SOURCE_VERSION_NAME}/easterrun.sh" --exclude="${SOURCE_VERSION_NAME}/stopserver.sh" --exclude="${SOURCE_VERSION_NAME}/env.properties" --exclude="${SOURCE_VERSION_NAME}/env" --exclude="${SOURCE_VERSION_NAME}/area-ice.client" --exclude="*/*.log" --exclude="*/logs/*.log*"  --exclude="*/.svn" --exclude="*/*.gif" --exclude="*/*.png" --exclude="*/*.psd" --exclude="*/*.bmp" --exclude="*/*.jpg" --exclude="*/*.doc" --exclude="*/*.docx" --exclude="${SOURCE_VERSION_NAME}/resources" -hczf ${TARGET_FULL_NAME} ${SOURCE_VERSION_NAME} && echo -e "execute success" || {echo -e "execute failure" ; rm -f ${TARGET_FULL_NAME}}


 rm -rf ${SOURCE_VERSION_NAME}
