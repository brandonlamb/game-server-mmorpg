#!/usr/bin/python
#-*- encoding: utf8 -*-


import tornado.ioloop
import tornado.httpserver
import tornado.web
import os
import sys

reload(sys)
sys.setdefaultencoding('utf8')


# Set up current directory to program directory
os.chdir(os.path.join(os.getcwd(), os.path.dirname(sys.argv[0])))

from handler.resource import ResHandler
from handler.hello_world import HelloWorldHandler
from handler.login import LoginHandler
from handler.logout import LogoutHandler

application = tornado.web.Application([
    (r"/", ResHandler),
    (r"/hello", HelloWorldHandler),
    (r"/login", LoginHandler),
    (r"/logout", LogoutHandler),
], template_path = "template", 
   static_path = "static",
   cookie_secret="61oETzKXQAGaYdkL5gEmGeJJFuYh7EQnp2XdTP1o/Vo=",
   login_url="/login"
)

if __name__ == "__main__":
    #启动httpserver
    http_server = tornado.httpserver.HTTPServer(application)
    http_server.listen(8080)
    tornado.ioloop.IOLoop.instance().start()
