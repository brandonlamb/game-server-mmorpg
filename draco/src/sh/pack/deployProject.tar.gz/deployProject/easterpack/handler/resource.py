#!/usr/bin/python
#-*- encoding: utf8 -*-

import tornado.web 
from func import func
from base import BaseHandler


class ResHandler(BaseHandler):
    @tornado.web.authenticated
    def get(self):
        name = tornado.escape.xhtml_escape(self.current_user)
        self.set_header('Content-Type', 'text/html')
        self.write(self.form_html('',name))
    
    @tornado.web.authenticated
    def post(self):
        name = tornado.escape.xhtml_escape(self.current_user)
        self.set_header('Content-Type', 'text/html')
        version = self.get_argument("v",'')
        type = self.get_argument("t",'')
        err_msg = ''
        if not func.is_correct_ver_format(version):
            err_msg = 'wrong version '
            self.write(self.form_html(err_msg,name))
            return 
        
        if type == 'sync':
            flag,resp = func.res_sync(version)
            self.write(self.result_html(type,flag,resp,name))
        else:
            flag,resp = func.res_pack(version)
            self.write(self.result_html(type,flag,resp,name))
    
    def result_html(self,type,flag,resp,name):
        msg = 'type:%s<br> success:%s<br><br> info:%s<br>'%(type,flag,resp)
        return self.form_html(msg,name)
        
        
    def form_html(self,msg,name):
        return '<html><body><form action="/" method="post">hello,' + name + '   <a href="/logout">Log out</a>' +  '<br><br>' + func.VER_MAPPING_INFO + '<br><br>version:<input type="text" name="v" id="v"/>(*)<br>\
    type:<select name="t" id="t"><option value ="sync">sync</option><option value ="pack">pack</option></select><br>\
    <input type="submit" value="Submit" /><br>' + msg +'</form></body></html>'
            
