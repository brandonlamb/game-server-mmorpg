#!/usr/bin/python
#-*- encoding: utf8 -*-

import tornado.web 

class HelloWorldHandler(tornado.web.RequestHandler):
        
    def get(self):
        data = 'hello,this is easter pack project'
        self.set_header('Content-Type', 'text/plain')
        self.set_header('Content-Length', len(data))
        self.write(data)
            
        