#!/usr/bin/python
#-*- encoding: utf8 -*-

import tornado.web 
from base import BaseHandler
from func import func

class LoginHandler(BaseHandler):
        
    def get(self):
        if self.current_user :
            self.redirect("/")
            
        self.set_header('Content-Type', 'text/html')
        self.write(self.form_html(''))
        
    def post(self):
        name = self.get_argument("name")
        pwd = self.get_argument("pwd")
        if not name or not pwd :
            self.write(self.form_html('error name or password'))
            return
        pwd_db = func.USERS.get(name,'')
        if not pwd_db or pwd_db != pwd :
            self.write(self.form_html('error name or password'))
            return
            
        self.set_secure_cookie("user", name)
        self.redirect("/")
   
            
    def form_html(self,msg):
        return '<html><body><form action="/login" method="post">'\
        'Name: <input type="text" name="name" id="name" /><br>'\
        'Password: <input type="password" name="pwd" id="pwd" /><br>'\
        '<input type="submit" value="Sign in" />' + '<br><br>' + msg + '</form></body></html>'

